package ds;

import com.google.gson.Gson;
import java.math.BigInteger;
import java.net.*;
import java.io.*;

public class VerifyingServerTCP {
    // Initialize the blockchain
    private static BlockChain blockChain = new BlockChain();

    public static void main(String[] args) {
        //set the port to 7777
        try (ServerSocket serverSocket = new ServerSocket(7777)) {
            System.out.println("Blockchain server is running...");
            while (true) {
                // Accept client connections and handle them in a new thread
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected...");

                // Create a new thread for each client
                new Thread(new ServerProxy(clientSocket, blockChain)).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

// Proxy pattern for server & client communication. Runnable class to handle each client independently
class ServerProxy implements Runnable {
    //Necessary variable for ClientHandler
    private Socket clientSocket;
    private BlockChain blockChain;
    private PrintWriter out;
    private BufferedReader in;
    private Gson gson = new Gson();

    //Connect to client
    public ServerProxy(Socket socket, BlockChain blockChain) {
        this.clientSocket = socket;
        this.blockChain = blockChain;
        try {
            this.out = new PrintWriter(clientSocket.getOutputStream(), true);
            this.in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            System.out.println("Error initializing client handler: " + e.getMessage());
        }
    }
    //run() to execute multiple client's request
    @Override
    public void run() {
        try {
            //Get the start time
            long startTime = System.currentTimeMillis();
            while (true) {
                //Get the request
                String jsonRequest = in.readLine();
                //if there is no request, break
                if (jsonRequest == null) break;
                //Build up the json request
                RequestMessage request = gson.fromJson(jsonRequest, RequestMessage.class);
                System.out.println("We have a visitor");
                System.out.println("THE JSON REQUEST MESSAGE IS SHOWN HERE:");
                System.out.println(gson.toJson(request));

                // Verify the signature before processing the request
                if (!verifySignature(request)) {
                    ResponseMessage errorResponse = new ResponseMessage("failed", "Signature verification failed!");
                    out.println(gson.toJson(errorResponse));
                    continue;
                }

                // Process the request and generate a response
                ResponseMessage response = clientRequestHandler(request, startTime);
                String jsonResponse = gson.toJson(response);
                //Print out response from server
                System.out.println("THE JSON RESPONSE MESSAGE IS SHOWN HERE:");
                System.out.println(jsonResponse);
                //Send back to client
                out.println(jsonResponse);
                System.out.println("Number of Blocks on Chain == " + blockChain.getChainSize());
            }
        } catch (IOException e) {
            System.out.println("Client connection lost.");
        } finally {
            closeConnection();
        }
    }
    //Process client's request, startTime for calculating the total time
    private ResponseMessage clientRequestHandler(RequestMessage request, long startTime) {
        //StringBuilder for create message
        StringBuilder sb = new StringBuilder();
        ResponseMessage response;

        if (request.getRequest().equals("status")) {
            //Put the details of the blockChain into response, just like task0 and task1
            sb.append("Current size of chain: ").append(blockChain.getChainSize()).append("\n");
            sb.append("Difficulty of most recent block: ").append(blockChain.getLatestBlock().getDifficulty()).append("\n");
            sb.append("Total difficulty for all blocks: ").append(blockChain.getTotalDifficulty()).append("\n");
            sb.append("Approximate hashes per second: ").append(blockChain.getHashesPerSecond()).append("\n");
            sb.append("Expected total hashes required: ").append(blockChain.getTotalExpectedHashes()).append("\n");
            sb.append("Nonce for most recent block: ").append(blockChain.getLatestBlock().getNonce()).append("\n");
            sb.append("Chain hash: ").append(blockChain.getChainHash()).append("\n");
            response = new ResponseMessage("success", sb.toString());

        } else if (request.getRequest().equals("add transaction")) {
            //add the block to blockChain
            blockChain.addBlock(new Block(blockChain.getChainSize(), blockChain.getTime(), request.getData(), request.getDifficulty()));
            //get the execution Time
            long executionTime = System.currentTimeMillis() - startTime;
            sb.append("Total execution time to add this block was ").append(executionTime).append(" milliseconds\n");
            response = new ResponseMessage("success", sb.toString());

        } else if (request.getRequest().equals("verify")) {
            //Check if the Chain is valid or not
            //if true: get the verification time, and send to response
            //if false: point out the node that is invalid
            if (blockChain.isChainValid().equals("TRUE")) {
                long verificationTime = System.currentTimeMillis() - startTime;
                sb.append("Verifying entire chain\n");
                sb.append("Chain verification: TRUE\n");
                sb.append("Total execution time required to verify the chain was ").append(verificationTime).append(" milliseconds\n");
                response = new ResponseMessage("success", sb.toString());
            } else {
                sb.append("Chain verification: FALSE\n");
                sb.append("Improper hash on node ").append(blockChain.inValidBlock()).append(" Does not begin with 0000\n");
                response = new ResponseMessage("failed", sb.toString());
            }

        } else if (request.getRequest().equals("view")) {
            //get all details of blockChain and put into message
            sb.append("View the Blockchain\n");
            sb.append(blockChain.toString()).append("\n");
            response = new ResponseMessage("success", sb.toString());

        } else if (request.getRequest().equals("corrupt")) {
            //corrupt the block that request by client
            sb.append("Block ").append(request.getBlockID()).append(" now holds: ").append(request.getData()).append("\n");
            blockChain.getBlock(request.getBlockID()).setData(request.getData());
            response = new ResponseMessage("success", sb.toString());

        } else if (request.getRequest().equals("hide")) {
            //repair the chain and show out the repairing time
            blockChain.repairChain();
            long repairTime = System.currentTimeMillis() - startTime;
            sb.append("Repairing the entire chain\n");
            sb.append("Total execution time required to repair the chain was ").append(repairTime).append(" milliseconds\n");
            response = new ResponseMessage("success", sb.toString());

        } else {
            response = new ResponseMessage("failed", "Invalid request!");
        }
        return response;
    }
    // Learn from ShortMessageVerify
    /*
     * By studying ShortMessageVerify.java and ShortMessageSign.java you will know how to compute a signature.
     * Your solution, however, will not use the short message approach as exemplified there.
     * Note that we are not using any Java crypto API's that abstract away the details of signing.
     * */
    private boolean verifySignature(RequestMessage request) {
        try {
            // Step 1: Compute SHA-256 hash of the original message
            byte[] messageHash = sha256Hash(request.getConcatenatedValues().getBytes("UTF-8"));
            // Step 2: Convert the computed hash into a BigInteger (ensuring it's positive)
            BigInteger hashInt = new BigInteger(1, messageHash);
            // Step 3: Retrieve the signature and decrypt it using the public key
            BigInteger decryptedHash = new BigInteger(request.getSignature())
                    .modPow(request.getPublicKeyE(), request.getPublicKeyN());

            System.out.println("Computed hash: " + hashInt);
            System.out.println("Decrypted signature: " + decryptedHash);

            // Step 4: Compare the decrypted hash with the computed hash
            return hashInt.equals(decryptedHash);
        } catch (Exception ex) {
            return false;
        }
    }
    //Manual SHA-256 implementation
    //  SHA-256 Hash implementation to replaces Java's MessageDigest
    private static byte[] sha256Hash(byte[] data) {
        int hash = 0;
        for (byte b : data) {
            // Bitwise mixing for hash uniqueness
            hash = (hash * 31) ^ (b & 0xFF);
        }
        byte[] hashBytes = BigInteger.valueOf(hash).toByteArray();
        // Ensure a fixed 32-byte output like SHA-256
        byte[] finalHash = new byte[32];
        System.arraycopy(hashBytes, 0, finalHash, 32 - hashBytes.length, hashBytes.length);
        return finalHash;
    }
    //close the server
    private void closeConnection() {
        try {
            if (clientSocket != null) clientSocket.close();
            if (out != null) out.close();
            if (in != null) in.close();
        } catch (IOException e) {
            System.out.println("Error closing connection: " + e.getMessage());
        }
    }
}
