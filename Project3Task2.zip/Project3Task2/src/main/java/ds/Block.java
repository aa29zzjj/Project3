package ds;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

public class Block {
    //required variables for Task 0
    //Block(int index, java.sql.Timestamp timestamp, java.lang.String data, int difficulty)
    private int index;
    private Timestamp timestamp;
    private String data;
    private String previousHash;
    private BigInteger nonce;
    private int difficulty;

    //Constructor
    public Block(int index, Timestamp timestamp, String data, int difficulty) {
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
        this.previousHash = "";
        //initialize nounce
        this.nonce = BigInteger.ZERO;
    }
    //This method computes a hash of the concatenation of the index, timestamp, data, previousHash, nonce, and difficulty.
    public String calculateHash() {
        try {
            //Use SHA-256 to compute the hash
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            //String of the index, timestamp, data, previousHash, nonce, and difficulty
            String input = index + timestamp.toString() + data + previousHash + nonce.toString() + difficulty;
            //get the hashBytes
            byte[] hashBytes = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            //Hexadecimal Conversion
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    //The proof of work methods finds a good hash. It increments the nonce until it produces a good hash.
    public String proofOfWork() {
        String target = "0".repeat(difficulty);
        //If the hash has the appropriate number of leading hex zeroes, it is done and returns that proper hash.
        // If the hash does not have the appropriate number of leading hex zeroes, it increments the nonce by 1 and tries again.
        // It continues this process, burning electricity and CPU cycles, until it gets lucky and finds a good hash.
        while (!calculateHash().substring(0, difficulty).equals(target)) {
            nonce = nonce.add(BigInteger.ONE);
        }
        return calculateHash();
    }
    //getter & setter
    public int getIndex() {
        return index;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public String getData() {
        return data;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public BigInteger getNonce() {
        return nonce;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    //toString method: set up the output by gson
    @Override
    public String toString() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject blockObj = new JsonObject();
        blockObj.addProperty("index", getIndex());
        blockObj.addProperty("time stamp ", getTimestamp().toString());
        blockObj.addProperty("Tx ", getData());
        blockObj.addProperty("PrevHash", getPreviousHash());
        blockObj.addProperty("nonce", getNonce().toString());
        blockObj.addProperty("difficulty", getDifficulty());

        return gson.toJson(blockObj);
    }
}
