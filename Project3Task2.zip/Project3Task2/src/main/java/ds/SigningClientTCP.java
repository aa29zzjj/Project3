package ds;

import com.google.gson.Gson;
import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.Random;
import java.util.Scanner;

public class SigningClientTCP {
    //follow the RSA example, setting the request for signature
    private static BigInteger e, d, n;
    //clientID for signature
    private static String clientID;
    private static final String localHost = "localhost";
    //serverPort = 7777
    private static final int serverPort = 7777;
    //gson for geneating the request
    private static Gson gson = new Gson();

    public static void main(String[] args) {
        //get from RSAExample.java, generate the clientID
        keysGenerator();
        //print out the clientID
        keysDisplayer();
        //scanner for client input
        Scanner scanner = new Scanner(System.in);
        //user Proxy pattern to encapsulate the connection
        ClientProxy proxy = new ClientProxy(localHost, serverPort);

        System.out.println("Client is running...");

        while (true) {
            // Display the menu
            System.out.println("0. View basic blockchain status.");
            System.out.println("1. Add a transaction to the blockchain.");
            System.out.println("2. Verify the blockchain.");
            System.out.println("3. View the blockchain.");
            System.out.println("4. Corrupt the chain.");
            System.out.println("5. Hide the corruption by repairing the chain.");
            System.out.println("6. Exit.");
            //select the choice
            int choice = scanner.nextInt();
            scanner.nextLine();

            RequestMessage requestMessage = null;

            if (choice == 0) {
                //0. View basic blockchain status.
                //Set the request to status
                requestMessage = new RequestMessage("status");
            } else if (choice == 1) {
                //1. Add a transaction to the blockchain.
                //enter the difficulty and task
                System.out.print("Enter difficulty > 1: ");
                int difficulty = scanner.nextInt();
                scanner.nextLine();
                //enter the transaction
                System.out.print("Enter transaction: ");
                String data = scanner.nextLine();
                //Set the request to add transaction
                requestMessage = new RequestMessage("add transaction", data, difficulty);
            } else if (choice == 2) {
                //2. Verify the blockchain.
                //Set the request to verify
                requestMessage = new RequestMessage("verify");
            } else if (choice == 3) {
                //3. View the blockchain.
                //Set the request to view
                requestMessage = new RequestMessage("view");
            } else if (choice == 4) {
                //4. Corrupt the chain.
                //Enter the block ID to corrupt
                System.out.print("Enter block ID of block to corrupt: ");
                int blockId = scanner.nextInt();
                scanner.nextLine();
                //Enter the new data for block
                System.out.print("Enter new data for block " + blockId + ": ");
                String newData = scanner.nextLine();
                //set the request to corrupt
                requestMessage = new RequestMessage("corrupt", blockId, newData);
            } else if (choice == 5) {
                //5. Hide the corruption by repairing the chain.
                //Set the request to hide
                requestMessage = new RequestMessage("hide");
            } else if (choice == 6) {
                //6. Exit.
                proxy.close();
                return;
            } else {
                System.out.println("Invalid choice. Try again.");
                continue;
            }
            //Set the information details in requestMessage
            requestMessage.setClientID(clientID);
            requestMessage.setPublicKey(e, n);
            requestMessage.setSignature(messageSigning(requestMessage.getConcatenatedValues()));
            //make it to json format
            String jsonRequest = gson.toJson(requestMessage);

            System.out.println("Sent: " + jsonRequest);
            //use proxy to get the Response from server
            String responseData = proxy.sendRequest(requestMessage);
            if (responseData != null) {
                ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                //Print out the message from server
                System.out.println("Response: ");
                System.out.println(responseMessage.getMessage());
            } else {
                System.out.println("Error: No response received from the server.");
            }
        }
    }
    //From RSAExample.java. used for generate the client ID
    private static void keysGenerator() {
        Random rnd = new Random();
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);
        n = p.multiply(q);
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        e = new BigInteger("65537");
        d = e.modInverse(phi);
        clientID = getClientId();
    }
    //display the key
    private static void keysDisplayer() {
        System.out.println("Client Public Key: e = " + e + ", n = " + n);
        System.out.println("Client Private Key: d = " + d + ", n = " + n);
        System.out.println("Client ID: " + clientID);
    }
    /*
    * The client's ID will be formed by taking the least significant 20 bytes of the hash of the client's public key.
    *  Note: an RSA public key is the pair e and n. Prior to hashing, you will combine these two integers with concatenation.
    *  The ID is computed in the client code. As in Bitcoin or Ethereum, the user's ID is derived from the public key.
    * */
    private static String getClientId() {
        try {
            //SHA-256 computing
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //use e and n to do the update
            md.update((e.toString() + n.toString()).getBytes());
            //get the byte of the md
            byte[] hash = md.digest();
            //Generate the client ID by taking the last 20 bytes of the SHA-256 hash of the public key
            //BigInteger(1, hash): to ensure the byte array hash is always positive
            //toString(16): hexadecimal
            return new BigInteger(1, hash).toString(16).substring(hash.length - 20);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /*
    * By studying ShortMessageVerify.java and ShortMessageSign.java you will know how to compute a signature.
    * Your solution, however, will not use the short message approach as exemplified there.
    * Note that we are not using any Java crypto API's that abstract away the details of signing.
    * */
    private static String messageSigning(String message) {
        try {
            // Step 1: Compute SHA-256 hash of the message (without Java Crypto APIs)
            byte[] messageHash = sha256Hash(message.getBytes("UTF-8"));

            // Step 2: Convert hash to a BigInteger (ensuring it's positive)
            BigInteger hashInt = new BigInteger(1, messageHash);

            // Step 3: Encrypt the hash using the private key (RSA signing)
            BigInteger signedValue = hashInt.modPow(d, n);

            // Step 4: Return the signature as a base-10 string
            return signedValue.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    // Manual SHA-256 implementation
    //  SHA-256 Hash implementation to replaces Java's MessageDigest
    private static byte[] sha256Hash(byte[] data) {
        int hash = 0;
        for (byte b : data) {
            // Bitwise mixing for hash uniqueness
            hash = (hash * 31) ^ (b & 0xFF);
        }
        byte[] hashBytes = BigInteger.valueOf(hash).toByteArray();

        // Ensure a fixed 32-byte output like SHA-256
        byte[] finalHash = new byte[32];
        System.arraycopy(hashBytes, 0, finalHash, 32 - hashBytes.length, hashBytes.length);
        return finalHash;
    }

}
//Handling the request
class RequestMessage {
    //variables for requestMessage
    private String request;
    private String data;
    private int difficulty;
    private int blockID;
    private String clientID;
    private String signature;
    private BigInteger e;
    private BigInteger n;

    // Constructors
    //For selection without setting values
    public RequestMessage(String request) {
        this.request = request;
    }
    //For selection need to add the block to block chain
    public RequestMessage(String request, String data, int difficulty) {
        this.request = request;
        this.data = data;
        this.difficulty = difficulty;
    }
    //For selection need to corrupt the block
    public RequestMessage(String request, int blockID, String data) {
        this.request = request;
        this.blockID = blockID;
        this.data = data;
    }

    // Getters and setters
    public String getRequest() { return request; }
    public String getData() { return data; }
    public int getDifficulty() { return difficulty; }
    public int getBlockID() { return blockID; }
    public String getSignature() { return signature; }
    public BigInteger getPublicKeyE() { return e; }
    public BigInteger getPublicKeyN() { return n; }
    public String getClientID(){
        return this.clientID;
    }

    public void setClientID(String clientID) { this.clientID = clientID; }
    public void setSignature(String signature) { this.signature = signature; }
    public void setPublicKey(BigInteger e, BigInteger n) {
        this.e = e;
        this.n = n;
    }
    //input the message such like request, data, clientID...etc to create the signature
    public String getConcatenatedValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(request);
        if (data != null) sb.append(data);
        if (difficulty > 0) sb.append(difficulty);
        if (blockID >= 0) sb.append(blockID);
        sb.append(clientID);
        return sb.toString();
    }
}
//Handle server's response
class ResponseMessage {
    private String status;
    private String message;

    // Constructor
    public ResponseMessage(String status, String message) {
        this.status = status;
        this.message = message;
    }

    // Getters and Setters
    public String getStatus() { return status; }
    public String getMessage() { return message; }
}
//Handle the client's connection, communication to server
class ClientProxy {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    private Gson gson = new Gson();
    //Constructor to connect to server
    public ClientProxy(String serverAddress, int serverPort) {
        try {
            this.socket = new Socket(serverAddress, serverPort);
            this.out = new PrintWriter(socket.getOutputStream(), true);
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //Send out the request and receive the response from server
    public String sendRequest(RequestMessage request) {
        try {
            String jsonRequest = gson.toJson(request);
            out.println(jsonRequest);
            out.flush();
            return in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    //close the connection once client select Exit
    public void close() {
        try {
            socket.close();
            out.close();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}