package ds;
import com.google.gson.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

public class BlockChain {
    //required variables
    private ArrayList<Block> chain;
    private String chainHash;
    private int hashesPerSecond;

    //default Constructor: initialize the block chain
    public BlockChain() {
        this.chain = new ArrayList<>();
        this.chainHash = "";
        Block genesis = new Block(0, getTime(), "Genesis", 2);
        genesis.proofOfWork();
        chain.add(genesis);
        this.chainHash = genesis.calculateHash();
    }
    //getter & setter
    public String getChainHash() {
        return chainHash;
    }

    public Timestamp getTime() {
        return new Timestamp(System.currentTimeMillis());
    }

    public Block getLatestBlock() {
        return chain.get(chain.size() - 1);
    }

    public int getChainSize() {
        return chain.size();
    }

    public int getHashesPerSecond() {
        return hashesPerSecond;
    }

    public void addBlock(Block newBlock) {
        newBlock.setPreviousHash(this.chainHash);
        newBlock.proofOfWork();
        this.chainHash = newBlock.calculateHash();
        chain.add(newBlock);
    }

    public Block getBlock(int i) {
        return chain.get(i);
    }

    //Compute and return the total difficulty of all blocks on the chain. Each block knows its own difficulty.
    public int getTotalDifficulty() {
        return chain.stream().mapToInt(Block::getDifficulty).sum();
    }

    //Compute and return the expected number of hashes required for the entire chain.
    public double getTotalExpectedHashes() {
        return chain.stream().mapToDouble(b -> Math.pow(16, b.getDifficulty())).sum();
    }

    //This method computes exactly 2 million hashes and times how long that process takes.
    // So, hashes per second is approximated as (2 million / number of seconds).
    // It is run on start up and sets the instance variable hashesPerSecond.
    // It uses a simple string - "00000000" to hash.
    public void computeHashesPerSecond() {
        long start = System.currentTimeMillis();
        for (int i = 0; i < 2000000; i++) {
            new Block(0, getTime(), "test", 2).calculateHash();
        }
        long end = System.currentTimeMillis();
        hashesPerSecond = (int) (2000000 / (end - start) * 1000);
    }
    //If the chain only contains one block, the genesis block at position 0,
    // this routine computes the hash of the block and checks that the hash has the requisite number of leftmost 0's (proof of work)
    // as specified in the difficulty field. It also checks that the chain hash is equal to this computed hash.
    // If either check fails, return an error message. Otherwise, return the string "TRUE".
    // If the chain has more blocks than one, begin checking from block one. Continue checking until you have validated the entire chain.
    // The first check will involve a computation of a hash in Block 0 and a comparison with the hash pointer in Block 1.
    // If they match and if the proof of work is correct, go and visit the next block in the chain.
    // At the end, check that the chain hash is also correct.
    public String isChainValid() {
        for (int i = 1; i < chain.size(); i++) {
            if (!chain.get(i).getPreviousHash().equals(chain.get(i - 1).calculateHash())) {
                return "FALSE";
            }
        }
        return "TRUE";
    }
    //Check which block is invalid
    public int inValidBlock(){
        for (int i = 1; i < chain.size(); i++) {
            if (!chain.get(i).getPreviousHash().equals(chain.get(i - 1).calculateHash())) {
                return i-1;
            }
        }
        return -1;
    }
    //This routine repairs the chain.
    // It checks the hashes of each block and ensures that any illegal hashes are recomputed.
    // After this routine is run, the chain will be valid.
    // The routine does not modify any difficulty values.
    // It computes new proof of work based on the difficulty specified in the Block.
    public void repairChain() {
        for (int i = 1; i < chain.size(); i++) {
            chain.get(i).proofOfWork();
            chain.get(i).setPreviousHash(chain.get(i - 1).calculateHash());
        }
        this.chainHash = getLatestBlock().calculateHash();
    }

    //toString method: set up the block information by Block.toString
    //Finally add the chainHash in the last part
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject blockchainObj = new JsonObject();

        JsonArray dsChainArray = new JsonArray();

        //Use StringBuilder to add the Json info
        for (Block block : chain) {
            dsChainArray.add(new JsonParser().parse(block.toString()));
        }

        //add the ds_chain and chainHash
        blockchainObj.add("ds_chain", dsChainArray);
        blockchainObj.addProperty("chainHash", this.chainHash);


        return gson.toJson(blockchainObj);
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //create a blockchain
        BlockChain blockchain = new BlockChain();
        //get the computeHashesPerSecond
        blockchain.computeHashesPerSecond();


        //Loop the selection manual
        while (true) {
            System.out.println("0. View basic blockchain status.");
            System.out.println("1. Add a transaction to the blockchain.");
            System.out.println("2. Verify the blockchain.");
            System.out.println("3. View the blockchain.");
            System.out.println("4. Corrupt the chain.");
            System.out.println("5. Hide the corruption by repairing the chain.");
            System.out.println("6. Exit.");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                //0. View basic blockchain status.
                case 0:
                    System.out.println("Current size of chain: " + blockchain.getChainSize());
                    System.out.println("Difficulty of most recent block: " + blockchain.getLatestBlock().getDifficulty());
                    System.out.println("Total difficulty for all blocks: " + blockchain.getTotalDifficulty());
                    System.out.println("Experimented with 2,000,000 hashes.");
                    System.out.println("Approximate hashes per second: " + blockchain.getHashesPerSecond());
                    System.out.println("Expected total hashes required: " + blockchain.getTotalExpectedHashes());
                    System.out.println("Nonce for most recent block: " + blockchain.getLatestBlock().getNonce());
                    System.out.println("Chain hash: " + blockchain.getChainHash());
                    break;
                // 1. Add a transaction to the blockchain.
                case 1:
                    System.out.print("Enter difficulty > 1: ");
                    int difficulty = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter transaction: ");
                    String data = scanner.nextLine();
                    long startTime = System.currentTimeMillis();
                    blockchain.addBlock(new Block(blockchain.getChainSize(), blockchain.getTime(), data, difficulty));
                    long endTime = System.currentTimeMillis();
                    System.out.println("Total execution time to add this block was " + (endTime - startTime) + " milliseconds");
                    break;
                // 2. Verify the blockchain.
                case 2:
                    long verifyStartTime = System.currentTimeMillis();
                    System.out.println("Verifying entire chain");
                    System.out.println("Chain verification: " + blockchain.isChainValid());
                    long verifyEndTime = System.currentTimeMillis();
                    long totalVerificationTime = verifyEndTime - verifyStartTime;
                    System.out.println("Total execution time required to verify the chain was "+ totalVerificationTime +" milliseconds");
                    break;
                // 3. View the blockchain.
                case 3:
                    System.out.println("View the Blockchain");
                    System.out.println(blockchain.toString());
                    break;
                //4. Corrupt the chain.
                case 4:
                    System.out.print("Enter block ID to corrupt: ");
                    int blockId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new data: ");
                    String newData = scanner.nextLine();
                    blockchain.getBlock(blockId).setData(newData);
                    System.out.println("Block " + blockId + " now holds: " + newData);
                    break;
                // 5. Hide the corruption by repairing the chain.
                case 5:
                    long repairStart = System.currentTimeMillis();
                    blockchain.repairChain();
                    long repairEnd = System.currentTimeMillis();
                    System.out.println("Total execution time required to repair the chain was " + (repairEnd - repairStart) + " milliseconds");
                    break;
                case 6:
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
