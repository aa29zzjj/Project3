package ds;

import com.google.gson.Gson;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ServerTCP {

    public static void main(String args[]) {
        Socket clientSocket = null;
        BlockChain blockChain = new BlockChain();
        Gson gson = new Gson();

        try {
            int serverPort = 7777; // the server port we are using

            // Create a new server socket
            ServerSocket listenSocket = new ServerSocket(serverPort);
            System.out.println("Blockchain server is running");
            clientSocket = listenSocket.accept();
            /*
             * Block waiting for a new connection request from a client.
             * When the request is received, "accept" it, and the rest
             * the tcp protocol handshake will then take place, making
             * the socket ready for reading and writing.
             */
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true);

            while (true) {
                //received the request from client
                String jsonRequest = in.readLine();
                if (jsonRequest == null) {
                    break;
                }
                //get the requestMessage, process the request by handleRequest
                RequestMessage request = gson.fromJson(jsonRequest, RequestMessage.class);
                ResponseMessage response = handleRequest(request, blockChain);
                //get the response
                String jsonResponse = gson.toJson(response);
                //send back to client
                out.println(jsonResponse);
            }

            // Handle exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting (typically by you sending quit signal) clean up sockets
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }
    // handle the different request from client
    private static ResponseMessage handleRequest(RequestMessage request, BlockChain blockchain) {
        //gson from print out the request and response
        Gson gson = new Gson();
        String blockchainJson = gson.toJson(blockchain);
        String cleanMessage = "";
        System.out.println("We have a visitor");
        System.out.println("THE JSON REQUEST MESSAGE IS SHOWN HERE");
        // Print the request as a clean JSON string
        System.out.println(gson.toJson(request));
        System.out.println("THE JSON RESPONSE MESSAGE IS SHOWN HERE");

        ResponseMessage response;
        if(request.getRequest().equals("status")){
            response = new ResponseMessage("success", blockchainJson);
            System.out.println(gson.toJson(response));
            System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
        } else if (request.getRequest().equals("add transaction")) {
            //Selection 1
            //add the block to blockchain by client's input
            blockchain.addBlock(new Block(blockchain.getChainSize(), blockchain.getTime(), request.getData(), request.getDifficulty()));
            response = new ResponseMessage("success", blockchain);
            System.out.println(gson.toJson(response));
            System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
        } else if (request.getRequest().equals("verify")) {
            //Selection 2
            //check the blockchain is valid or not
            if(blockchain.isChainValid().equals("TRUE")){
                response = new ResponseMessage("success", blockchain.isChainValid());
                System.out.println(gson.toJson(response));
                System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
            }else{
                response = new ResponseMessage("success", blockchain.isChainValid(), blockchain.inValidBlock());
                System.out.println(gson.toJson(response));
                System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
            }
        } else if (request.getRequest().equals("view")) {
            //Selection 3
            //print out the whole block in blockchain
            response = new ResponseMessage("success", blockchainJson);
            System.out.println(gson.toJson(response));
            System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
        } else if (request.getRequest().equals("corrupt")) {
            //Selection 4
            //corrupt the block by client's input
            blockchain.getBlock(request.getBlockID()).setData(request.getData());
            response = new ResponseMessage("success", "Block " + request.getBlockID() + " modified.");
            System.out.println(gson.toJson(response));
            System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
        } else if (request.getRequest().equals("hide")) {
            //Selection 5
            //repair the blockchain
            blockchain.repairChain();
            response = new ResponseMessage("success", "Blockchain repaired.");
            System.out.println(gson.toJson(response));
            System.out.println("Number of Blocks on Chain == "+ blockchain.getChainSize());
        }else{
            response = new ResponseMessage("failed", "Invalid request.");
            System.out.println(gson.toJson(response));
        }
        return response;

    }
}
