package ds;

import com.google.gson.Gson;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ClientTCP {

    public static void main(String args[]) {
        // arguments supply hostname
        Socket clientSocket = null;
        //Scanner for client input
        Scanner scanner = new Scanner(System.in);
        try {
            //serverPort = 7777
            int serverPort = 7777;
            //connect to port 7777
            clientSocket = new Socket( "localhost", serverPort);
            System.out.println("Client is running...");
            //use BufferReader to read the response
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            //use PrintWriter to send the request
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            //gson for request message
            Gson gson = new Gson();

            while (true) {
                //Selection manual
                System.out.println("0. View basic blockchain status.");
                System.out.println("1. Add a transaction to the blockchain.");
                System.out.println("2. Verify the blockchain.");
                System.out.println("3. View the blockchain.");
                System.out.println("4. Corrupt the chain.");
                System.out.println("5. Hide the corruption by repairing the chain.");
                System.out.println("6. Exit.");
                //input the selection
                int choice = scanner.nextInt();
                scanner.nextLine();


                if (choice == 0) {
                    //0. View basic blockchain status.
                    //set the request message
                    RequestMessage requestMessage = new RequestMessage("status");
                    //set into json
                    String jsonRequest = gson.toJson(requestMessage);
                    //send the request and use flush() to confirm the streamline
                    out.println(jsonRequest);
                    out.flush();
                    //received the server response
                    String responseData = in.readLine();
                    if (responseData != null) {
                        //get the response message
                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        //check if server processed the request
                        if ("success".equals(responseMessage.getStatus())) {
                            // Deserialize JSON response to an appropriate object
                            BlockChain status = gson.fromJson(responseMessage.getMessage(), BlockChain.class);

                            // Display blockchain status
                            System.out.println("Current size of chain: " + status.getChainSize());
                            System.out.println("Difficulty of most recent block: " + status.getLatestBlock().getDifficulty());
                            System.out.println("Total difficulty for all blocks: " + status.getTotalDifficulty());
                            System.out.println("Experimented with 2,000,000 hashes.");
                            System.out.println("Approximate hashes per second: " + status.getHashesPerSecond());
                            System.out.println("Expected total hashes required: " + status.getTotalExpectedHashes());
                            System.out.println("Nonce for most recent block: " + status.getLatestBlock().getNonce());
                            System.out.println("Chain hash: " + status.getChainHash());
                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }

                    } else {
                        System.out.println("Error: No response received from the server.");
                    }

                }else if (choice == 1){
                    // "1. Add a transaction to the blockchain."
                    // get the startTime
                    long startTime = System.currentTimeMillis();
                    //set difficulty
                    System.out.print("Enter difficulty > 1: ");
                    int difficulty = scanner.nextInt();
                    scanner.nextLine();
                    //set the transaction
                    System.out.print("Enter transaction: ");
                    String data = scanner.nextLine();

                    //set the requestMessage and sent to the server
                    RequestMessage requestMessage = new RequestMessage("add transaction", data, difficulty);
                    String jsonRequest = gson.toJson(requestMessage);
                    //do the same thing as previous option
                    out.println(jsonRequest);
                    out.flush();
                    //receive the server response
                    String responseData = in.readLine();
                    //check if the response has value
                    if (responseData != null) {
                        //get the responseMessage
                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        //Check if server processed the request
                        if ("success".equals(responseMessage.getStatus())) {
                            // Deserialize JSON response to an appropriate object
                            BlockChain status = gson.fromJson(responseData, BlockChain.class);
                            long endTime = System.currentTimeMillis();
                            //calculate the processing time
                            System.out.println("Total execution time to add this block was " + (endTime - startTime) + " milliseconds");
                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }

                    } else {
                        System.out.println("Error: No response received from the server.");
                    }

                }else if (choice == 2){
                    // 2. Verify the blockchain.
                    // same thing as previous selection
                    long verifyStartTime = System.currentTimeMillis();
                    RequestMessage requestMessage = new RequestMessage("verify");
                    String jsonRequest = gson.toJson(requestMessage);

                    out.println(jsonRequest);
                    out.flush();

                    String responseData = in.readLine();

                    if (responseData != null) {

                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        if ("success".equals(responseMessage.getStatus())) {
                            if(responseMessage.getMessage().equals("TRUE")){
                                //check the chain verification
                                System.out.println("Verifying entire chain");
                                System.out.println("Chain verification: " + responseMessage.getMessage());
                                long verifyEndTime = System.currentTimeMillis();
                                //get the total verification time.
                                long totalVerificationTime = verifyEndTime - verifyStartTime;
                                System.out.println("Total execution time required to verify the chain was "+ totalVerificationTime +" milliseconds");
                            }else{
                                System.out.println("Verifying entire chain");
                                System.out.println("Chain verification: " + responseMessage.getMessage());
                                System.out.println("Improper hash on node " + responseMessage.getInvalidBlock() + " Does not begin with 0000");
                            }

                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }


                    } else {
                        System.out.println("Error: No response received from the server.");

                    }


                }else if (choice == 3){
                    //3. View the blockchain.
                    //do the same thing as previous request, but different action message
                    RequestMessage requestMessage = new RequestMessage("view");
                    String jsonRequest = gson.toJson(requestMessage);

                    out.println(jsonRequest);
                    out.flush();

                    String responseData = in.readLine();
                    if (responseData != null) {
                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        if ("success".equals(responseMessage.getStatus())) {
                            BlockChain status = gson.fromJson(responseMessage.getMessage(), BlockChain.class);
                            System.out.println("View the Blockchain");
                            //print out the whole blockchain
                            System.out.println(status.toString());
                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }
                    } else {
                        System.out.println("Error: No response received from the server.");
                    }

                }else if (choice == 4){
                    //4. Corrupt the chain.
                    //do the same thing as previous request, but different action message
                    //set the corrupt id
                    System.out.print("Enter block ID of block to corrupt: ");
                    int blockId = scanner.nextInt();
                    scanner.nextLine();
                    //enter the new data
                    System.out.print("Enter new data for block "+ blockId+ ": ");
                    String newData = scanner.nextLine();
                    //send the request to server
                    RequestMessage requestMessage = new RequestMessage("corrupt", blockId, newData);
                    String jsonRequest = gson.toJson(requestMessage);

                    out.println(jsonRequest);
                    out.flush();

                    String responseData = in.readLine();

                    if (responseData != null) {
                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        if ("success".equals(responseMessage.getStatus())) {
                            //print out the block that user intend to change
                            System.out.println("Block " + blockId + " now holds: " + newData);
                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }

                    } else {
                        System.out.println("Error: No response received from the server.");
                    }

                }else if (choice == 5){
                    //5. Hide the corruption by repairing the chain.
                    //do the same thing as previous selection, but different action message
                    long repairStart = System.currentTimeMillis();
                    RequestMessage requestMessage = new RequestMessage("hide");
                    String jsonRequest = gson.toJson(requestMessage);

                    out.println(jsonRequest);
                    out.flush();

                    String responseData = in.readLine();

                    if (responseData != null) {
                        ResponseMessage responseMessage = gson.fromJson(responseData, ResponseMessage.class);
                        if ("success".equals(responseMessage.getStatus())) {
                            long repairEnd = System.currentTimeMillis();
                            System.out.println("Repairing the entire chain");
                            //print out the total repaired time
                            System.out.println("Total execution time required to repair the chain was " + (repairEnd - repairStart) + " milliseconds");

                        } else {
                            System.out.println("Error: " + responseMessage.getMessage());
                        }

                    } else {
                        System.out.println("Error: No response received from the server.");
                    }

                }else if (choice == 6){
                    //6. Exit.
                    scanner.close();
                    return;
                }
            }

        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }
}
//request from client
class RequestMessage {
    //request: request action
    private String request;
    //info that need client to set
    private String data;
    private int difficulty;
    private int blockID;
    //Constructors
    public RequestMessage(String request, String data, int difficulty) {
        this.request = request;
        this.data = data;
        this.difficulty = difficulty;
    }

    public RequestMessage(String request) {
        this.request = request;
    }

    public RequestMessage(String request, int blockID, String data) {
        this.request = request;
        this.data = data;
        this.blockID = blockID;
    }
    //getters
    public String getRequest() { return request; }
    public String getData() { return data; }
    public int getDifficulty() { return difficulty; }
    public int getBlockID() { return blockID; }
}

class ResponseMessage {
    //status: to confirm server process the request or not
    private String status;
    //info for making response
    private BlockChain blockChain;
    private String message;
    private int invalidBlock;
    //constructor
    public ResponseMessage(String status, BlockChain blockChain) {
        this.status = status;
        this.blockChain = blockChain;
    }

    public ResponseMessage(String status, String message) {
        this.status = status;
        this.message = message;
    }
    public ResponseMessage(String status, String message, int invalidBlock) {
        this.status = status;
        this.message = message;
        this.invalidBlock = invalidBlock;
    }
    //getters
    public String getStatus() { return status; }
    public BlockChain getBlockChain() { return blockChain; }
    public String getMessage() { return message; }
    public int getInvalidBlock() { return invalidBlock; }
}
